<?php
   // Get the values from the query.
   $val1 = $_GET["val1"];
   $val2 = $_GET["val2"];
   
   // Perform the math operation.
   $result = $val1 + $val2;
   
   // Output the result.
   echo $result;
?>