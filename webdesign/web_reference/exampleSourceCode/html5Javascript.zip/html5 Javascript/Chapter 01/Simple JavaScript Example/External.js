function ExternalSayHello()
{
    alert("This is the ExternalSayHello() function!");
}